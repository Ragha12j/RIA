import React, { Component, Fragment } from 'react';

import HomeTop from '../components/home/HomeTop';
import Cake from '../components/home/Cake';
import View from '../components/home/View';



export class HomePage extends Component {
  constructor(){
    super();
    window.scroll(0,0)

    }
  render() {
    return (
      <Fragment>
        <HomeTop />
        <Cake />
        <View />
      
        
        
      </Fragment>
    )
  }
}

export default HomePage
