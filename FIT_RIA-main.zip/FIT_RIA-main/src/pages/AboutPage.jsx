import React, { Component, Fragment } from 'react'

import Menu from '../components/home/Menu';



export class AboutPage extends Component {
  constructor(){
    super();
    window.scroll(0,0)

    }
  render() {
    return (
      <Fragment>
        <Menu />
       
       
      </Fragment>
    )
  }
}

export default AboutPage
