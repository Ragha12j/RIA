import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';
import {Container, Row, Col, Card} from 'react-bootstrap';

export class Menu extends Component {
  render() {
    return (
        <Fragment>
            <Container className="text-center mt-5" fluid>
                <div className='section-title text-center mb-55'>
                    <h2>MENU</h2>
                    <p>choose your orders . here is the best!</p>
                </div>
                <Row>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/mm.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>alfrido</p>
                                    <p>Price: 50$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/ff.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>break fast </p>
                                    <p>Price: 100$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/ss.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>savory supper</p>
                                    <p>Price: 30$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/pp.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>action butintion</p>
                                    <p>Price: 10$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/ee.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>flavorful </p>
                                    <p>Price: 440$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/aa.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>comform food</p>
                                    <p>Price: 500$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/bb.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>burger</p>
                                    <p>Price: 550$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/kk.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>tasty treas</p>
                                    <p>Price: 100$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/rr.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>herty bronsh</p>
                                    <p>Price: 100$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/cc.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>cake red felvet</p>
                                    <p>Price: 900$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/ss.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>lunchtime fets</p>
                                    <p>Price: 4400$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/bb.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Perfect New Laptop with Process i3</p>
                                    <p>Price: 100$</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                </Row>
            </Container>   
      </Fragment>
    )
  }
}

export default Menu
