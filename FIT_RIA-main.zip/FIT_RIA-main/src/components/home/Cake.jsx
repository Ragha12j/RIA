import React, { Component, Fragment } from 'react';

import Col from 'react-bootstrap/Col'; 
import Container from 'react-bootstrap/Container'; 
import Image from 'react-bootstrap/Image'; 
import Row from 'react-bootstrap/Row'; 

export class Cake extends Component {
  render() {
    return (
      <div>
        <Fragment>
                <Container> 
                    <br />
                    <Row> 
                        <br />
        <Col xs={6} md={4}> 
          <Image width={200} height={200} src={require('../../assets/images/cc.jpg')} roundedCircle /> 
        </Col> 
        <Col xs={6} md={4}> 
          <Image width={200} height={200} src={require('../../assets/images/cc1.jpg')} roundedCircle /> 
        </Col> 
        <Col xs={6} md={4}> 
          <Image width={200} height={200} src={require('../../assets/images/cc2.jpg')} roundedCircle /> 
        </Col> 
      </Row> 
    </Container> 
        </Fragment>
      </div>
    )
  }
}

export default Cake
