import React, { Component } from 'react';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";

export class HomeSlider extends Component {
  render() {
    const settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      autoplayspeed: 1500
    };
    return (
      <div>
        
        <Slider {...settings}>
          <div>
            <h3><img alt="First slider" width={900} height={500} src={require('../../assets/images/im1.jpg')} /></h3>
          </div>
          <div>
            <h3><img alt="First slider" width={900} height={500} src={require('../../assets/images/im2.jpg')} /></h3>
          </div>
          <div>
            <h3><img alt="First slider" width={900} height={500} src={require('../../assets/images/im3.jpg')} /></h3>
          </div>
          <div>
            <h3><img alt="First slider" width={900} height={500} src={require('../../assets/images/im4.jpg')} /></h3>
          </div>
        
        </Slider>
      </div>
    );
  }
}

export default HomeSlider
