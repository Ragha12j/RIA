import React, { Component } from 'react';
import Button from 'react-bootstrap/Button'; 
import Card from 'react-bootstrap/Card';
 

export class Chef extends Component {
  render() {
    return (
      <div>
        <br /><br /><br />
        <Card style={{ width: '18rem' }}> 
      <Card.Img variant="top" src={require('../../assets/images/chef.jpeg')} /> 
      <Card.Body> 
        <Card.Title>jorden ramzy</Card.Title> 
        <Card.Text> 
        Michelin stars. Known for his volatile kitchen demeanour and exceptional British cuisine, Gordon Ramsay is arguably the most
        </Card.Text> 
        <Button variant="primary">view more</Button> 
      </Card.Body> 
    </Card> 
   
      </div>
    )
  }
}

export default Chef
