import React, { Component, Fragment } from 'react';
import { Container, Row } from 'react-bootstrap';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import Spinner from 'react-bootstrap/Spinner';
import Card from 'react-bootstrap/Card';

export class View extends Component {

    constructor() {
        super();
        this.next = this.next.bind(this);
        this.previous = this.previous.bind(this)
    }
    next() {
        this.slider.slickNext();
    }
    previous() {
        this.slider.slickPrev();
    }
    render() {
        const settings = {
            dots: false,
            infinite: true,
            speed: 500,
            slidesToShow: 4,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 1500,
        };
        return (
            <div>
                <Fragment>
                    <Container className="text-center mt-5" fluid>
                        <div className='section-title text-center mb-55'>
                            <a className="btn btn-sm ml-2 site-btn" onClick={this.previous}><i className='fa fa-angle-left'></i></a>
                            <a className="btn btn-sm ml-2 site-btn" onClick={this.next}><i className='fa fa-angle-right'></i></a>
                            <h2>OUR RESTURENT</h2>
                            <p>Some of our own spaces, You May Like</p>
                        </div>
                        <Row>
                            <Slider ref={c => (this.slider = c)} {...settings}>
                                <div>
                                    
                                        <>
                                            <br />
                                            <Card>
                                                <Card.Body>
                                                    <Card.Text>
                                                        space to rest in it ..
                                                    </Card.Text>
                                                </Card.Body>
                                                <Card.Img variant="bottom" src={require('../../assets/images/re.jpg')} />
                                            </Card>
                                        </>
                                    
                                </div>
                                <div>
                                   
                                        <>
                                            <br />
                                            <Card>
                                                <Card.Body>
                                                    <Card.Text>
                                                        have perfect view and the best
                                                    </Card.Text>
                                                </Card.Body>
                                                <Card.Img variant="bottom" src={require('../../assets/images/re1.jpg')} />
                                            </Card>
                                        </>
                                    
                                </div>
                                <div>
                                   
                                        <>
                                            <br />
                                            <Card>
                                                <Card.Body>
                                                    <Card.Text>
                                                        our title is cheaper faster and the best and goodest food
                                                    </Card.Text>
                                                </Card.Body>
                                                <Card.Img variant="bottom" src={require('../../assets/images/re2.jpg')} />
                                            </Card>
                                        </>
                                   
                                </div>
                                <div>

                                    <>
                                        <br />
                                        <Card>
                                            <Card.Body>
                                                <Card.Text>
                                                    enjoi your time 
                                                </Card.Text>
                                            </Card.Body>
                                            <Card.Img variant="bottom" src={require('../../assets/images/re3.jpg')} />
                                        </Card>
                                    </>

                                </div>

                            </Slider>
                        </Row>
                    </Container>
                    <>
                        <Spinner animation="border" size="sm" />
                        <Spinner animation="border" />
                        <Spinner animation="grow" size="sm" />
                        <Spinner animation="grow" />
                    </>
                </Fragment>
            </div>
        )
    }
}

export default View
