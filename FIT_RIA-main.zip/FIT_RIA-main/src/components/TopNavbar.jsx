import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import Logo from'../assets/images/relogo.png';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

export class TopNavbar extends Component {
  render() {
    return (
      <Navbar expand="lg" className="bg-body-tertiary"> 
        <Container fluid> 
          <Col lg={4} md={4} sm={12} xs={12}>
            <Navbar.Brand href="#">
              <Link to="/"><img alt="Restaurant logo" src={Logo} width={80} height={80} className='d-inline-block'></img></Link>
                Restaurant
            </Navbar.Brand> 
            </Col>
        <Navbar.Toggle aria-controls="navbarScroll" /> 
        <Navbar.Collapse id="navbarScroll"> 
          <Nav 
            className="me-auto my-2 my-lg-0" 
            style={{ maxHeight: '100px' }} 
            navbarScroll 
          > 
            <Nav.Link href="/profile">Home</Nav.Link> 
            <Nav.Link href="/menu">Menu</Nav.Link> 
            <NavDropdown title="Orders" id="navbarScrollingDropdown"> 
                <NavDropdown.Item href="/order_now">order now</NavDropdown.Item> 
                <NavDropdown.Item href="/contact_us">contact us</NavDropdown.Item> 
              <NavDropdown.Item href="/about_us"> 
                about us
              </NavDropdown.Item> 
              <NavDropdown.Divider /> 
            </NavDropdown> 
            
          </Nav> 
          <Form className="d-flex"> 
            <Form.Control 
              type="search" 
              placeholder="Search" 
              className="me-2" 
              aria-label="Search" 
            /> 
            <Button variant="outline-warning">Search</Button> 
          </Form> 
        </Navbar.Collapse> 
      </Container> 
    </Navbar>
    );
  }
}
export default TopNavbar
