import React, { Component, Fragment } from 'react';
import {Container, Row, Col, Button} from 'react-bootstrap';
import { Link } from 'react-router-dom';
export class Footer extends Component {
  render() {
    return (
      <Fragment>
        <div className="bg-warning text-white">
            <Container >
                <Row>
                    <Col className='p-2' lg={3} md={3} sm={6}>
                            <h5>Contact us</h5>
                            <a href="/"><i className='fab mt-4 m-2 h4 fa-snapchat' style={{color:"#ffffff",}}></i></a>
                        <a href="/"><i className='fab mt-4 m-2 h4 fa-facebook' style={{color:"#ffffff",}}></i></a>
                        <a href="/"><i className='fab mt-4 m-2 h4 fa-twitter' style={{color:"#ffffff",}}></i></a>
                    </Col>
                    <Col className='p-2' lg={3} md={3} sm={6}>
                        <h5>More Information</h5>
                        <p><Button variant="light">Purchase Police</Button></p>
                        <p><Button variant="light">Privacy Policy</Button></p>
                        <p><Button variant="light">Refund Policy</Button></p>

                    </Col>
                    <Col className='p-2' lg={3} md={3} sm={6}>
                        <h5>About Resturent</h5>
                        <p><Link to="/menu"><Button variant="light">Menu</Button></Link></p>
                        <p><Link to="/about_us"><Button variant="light">About us</Button></Link></p>
                        <p><Link to="/contact_us"><Button variant="light">Contact us</Button></Link></p>
                    </Col>
                    <Col className='p-2' lg={3} md={3} sm={6}>
                        <h5>Resturent Address</h5>
                        <p>SAS near to KARAM of COFFEE - Misrata, Libya</p>
                        <span><i className='fa fa-envelope'></i> chef@xxx.xx</span>
                    </Col>
                </Row>
            </Container>
            <Container fluid className='text-center m-0 pt-3 pb-1 bg-light text-black'>
         
            </Container>
        </div>
      </Fragment>
    )
  }
}

export default Footer
