import React, { Component, Fragment } from 'react';
//import {Container, Row, Col, Form, Button} from 'react-bootstrap';
//import { Link } from 'react-router-dom';
import Card from 'react-bootstrap/Card'; 



export class About extends Component {
  render() {
    return (
      <Fragment>
         <Card> 
      <Card.Header>About us</Card.Header> 
      <Card.Body> 
        <blockquote className="blockquote mb-0"> 
          <p> 
            {' '} 
            we believe that dining is not just about satisfying your hunger, but about creating memorable experiences. We are a premier restaurant dedicated to providing exceptional service, delectable cuisine, and a warm and inviting atmosphere. Whether you're joining us for a casual lunch, a romantic dinner, or celebrating a special occasion, we strive to make every visit to our restaurant truly extraordinary.{' '} 
          </p> 
              <footer className="blockquote-footer"> 
                <br />
                Someone famous in <cite title="Source Title">Jorden ramzy</cite> 
                <br /><br />
          </footer> 
        </blockquote> 
      </Card.Body> 
    </Card> 
      </Fragment>
    )
  }
}

export default About
