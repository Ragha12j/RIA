import React, { Component, Fragment } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import Button from 'react-bootstrap/Button'; 
import Form from 'react-bootstrap/Form';

export class Contact extends Component {
  render() {
    return (
      <Fragment>
        <Container>
            <Row>
                <Col className="shadow-sm bg-white mt-2" lg={12} md={12} sm={12} xs={12}>
                    <Row className='text-center'>
                        <Col className="p-0 m-0" lg={6} md={6} sm={6} xs={6}>
                            <p>You can reach out our resturent nearby the 4th road</p>
                            <iframe title='FIT Location' src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d215689.54888334413!2d15.046576545024191!3d32.361542838989855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1z2YXYt9i52YUg2KfZhNmF2K_ZitmG2Kk!5e0!3m2!1sen!2sly!4v1708102752822!5m2!1sen!2sly" width="600" height="400" styles="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </Col>
                        <Col className="d-flex justify-content-center mt-5" lg={6} md={6} sm={6} xs={6}>
                        <Form> 
      <Form.Group className="mb-3" controlId="formBasicEmail"> 
        <Form.Label>Email address</Form.Label> 
        <Form.Control type="email" placeholder="Enter email" /> 
        <Form.Text className="text-muted"> 
          We'll never share your email with anyone else. 
        </Form.Text> 
      </Form.Group> 
 
      <Form.Group className="mb-3" controlId="formBasicPassword"> 
        <Form.Label>Password</Form.Label> 
        <Form.Control type="password" placeholder="Password" /> 
      </Form.Group> 
      <Form.Group className="mb-3" controlId="formBasicCheckbox"> 
        <Form.Check type="checkbox" label="Check me out" /> 
      </Form.Group> 
      <Button variant="warning" type="submit"> 
        Submit 
      </Button> 
    </Form> 
                        </Col>
                    </Row>        
                </Col>
            </Row>
        </Container>
      </Fragment>
    )
  }
}

export default Contact
